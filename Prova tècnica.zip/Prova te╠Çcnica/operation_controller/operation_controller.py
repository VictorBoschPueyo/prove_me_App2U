from typing import Any, List


class OperationController:

    def __init__(self, operations: List[Any]) -> None:

        self.operations = operations
        self.current_operation_index = 0

    def start(self) -> None:
        print("Start operations")
        self.execute_next_operation()

    def execute_next_operation(self) -> None:
        from operation_controller.operations.get_files_http_operation import GetFilesHTTPOperation
        from operation_controller.operations.get_files_sftp_operation import GetFilesSFTPOperation

        if self.current_operation_index < len(self.operations):
            # Get next operation, set parameters and start
            operation = self.operations[self.current_operation_index]

            if isinstance(operation, GetFilesSFTPOperation):
                operation.set_controller(self)
                operation.download_from_sftp()
            if isinstance(operation, GetFilesHTTPOperation):
                operation.set_controller(self)
                operation.download_from_web()
            else:
                self.operations_error()
        else:
            self.operations_completed()

    def operation_error(self, operation: Any, message: str) -> None:
        self.operations_error()

    def operation_completed(self, operation: Any) -> None:
        self.current_operation_index += 1
        self.execute_next_operation()

    def operations_error(self) -> None:
        print("Process finished with errors")

    def operations_completed(self) -> None:
        print("Process finished successfully")
